WinBrick Version 2.05b                                                 10.8.1996
Stefan Kuhne
Telephone : +5331-902247
Fax       : +5331-902248
Address   : Dr. Kirchheimer Str. 3a, 38304 Wolfenbuettel, Germany
e-Mail    : StKuhne@aol.com
WWW       : http://users.aol.com/StKuhne  - Here is the latest news for
                                            WinBrick and new products!!
_______________________________________________________________________________

0.0 Short index
===============

1.0     Latest changes
2.0     Known problems
3.0     Registration form

_______________________________________________________________________________

1.0 Latest changes
==================

Version 2.05b:
    o The US-contact address has been updated
    o The english language strings has been updated

Version 2.05a:
    o French language support added to the game.

Version 2.05:
    o 'Solid objects' are now working with more than 256 colors.
    o If the old WinBrick version had trouble with your second mouse port,
      it should not crash any more (hopefully).
    o The palette management with 256 colors has been improved now.
    o You are now able to use a 'boss key'.
    o The flashing of text is now optional.

Version 2.04a:
    o I am now on-line: a WWW site and a new e-mail address

Version 2.04:
    o When leaving the 20th level, you'll go automatically to the next scenery.
    o The 32bit version of WinBrick 96 is now also able to play the two player
      mode with a network connection!!
    o 40 new levels have been added
    o Additional rules for the network game:
        - The name for the HiScore list will be automatically the players name.
        - The HiScore list has 16 entrys and will be updated when starting
          a network game.
    o The HiScore list will now also be updated if you accept a credit.
    o Some optical enhancements.
    o Within the two player game, you are able to decide, wether the sides
      will be swapped after a level completition or not.

Version 2.03:
    o The appearance of the game with 256 colors is now nearly the same as with
      true color.
    o Some small optical errors solved.

Version 2.02:
    o Some visual enhancements.
    o Some small errors fixed.
 
Version 2.01:
    o Level editor added.
    o Some small errrors fixed.

Version 2.00:
    o Configuration is now Windows 95 like (with property pages) + direct help.
    o Zoom to fullscreen as a option.
    o Sound volume is now adjustable.
    o In 2 Player mode, you are now able to fire rockets.
    o There are now two new 'brick type's: Lightening and 'opponent lightening'.
    o The maximum of simultaniously displayed objects is now 64+16.
    o It's much faster now.
    o Fireing Rockets is now done by pressing both buttons at once.
    o For speed improvement and a better reading, the rotating score could now
      be disbaled.
    o Demo mode implemented.
    o Three new special objects have been implemented:
           - 15-Ball explode
           - 8 Lightening explode
           - 3 Level jump
    o Levels are scrolling through.
    o And much more...

_______________________________________________________________________________

2.0 Known problems
==================
    o Joystick control 'absolut' is unstable.----------------------------------
       The physical joystick hardware is implemented very cheap in the most
       cases. Soundeffects for example may move the racket a little bit
       randomly.
    o The game seems to pause sometimes with heavy action.---------------------
       Some sound drivers use very much time to stop Sound. If you have one
       of these, you may disable sound effects.
    o No second mouse support with Windows NT.
    o Window to small (some graphics are cut off)? Try a smaller system font!
    o The 32 Bit Version of Winbrick96 did not run with Windows 32s
       (extension to Windows 3.x)!

_______________________________________________________________________________

3.0 Registration form
=====================

 
Please send this registration form and a cheque/money (only US-$!!) to the
following address:

Rest of the world:                     North America:

Stefan Kuhne                           Danny Klopfer
Dr. Kirchheimer Str. 3a                664-A Freeman Lane Suite 449
38304 Wolfenbuettel                    Grass Valley
Germany                                CA 95949 - USA
StKuhne@aol.com                        danny@unirom.com
(credit cards are NOT accepted!!)      (Credit cards accepted!!)

 
Quant.  Item                                                     Price
 
_____   WinBrick 96                             @ 30.-US$ each $________

_____   Registration of level editor for WinBrick96
        - design your own levels! -             @ 10.-US$ each $________

_____   Update from registered WinBrick 1.x
        You have to send back the original disk @ 15.-US$ each $________

(  )    Shipping cost for mail                  @ 10.-US$      $________
        OR
(  )    Shipping for eMail                      @  3.-US$      $________
          (don't forget your eMail address)
                                                                ========
                                                     Overall:   ________
 

I want this Version:

   ( ) 32 Bit - runs on Windows 95/NT only (faster, more objects, network)

   ( ) 16 Bit - runs on Windows 3.x/95/NT,OS/2
 
   If nothing is checked, I get the 16 bit version of the game!



Name:           _________________________________________________________ 
 
Company:        _________________________________________________________ 
 
Address:        _________________________________________________________ 
 		
		_________________________________________________________

State:          _________________________________________________________

eMail:          _________________________________________________________


 
Signature               __________________________________________ 
 


