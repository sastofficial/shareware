

			    -<< Hardwood Solitaire >>-

		** 256 and *TRUE COLOR WINDOWS 95* Solitaire Games **



 Hardwood Solitaire is a stunning rendition of three popular 
solitaire games: Klondike, Pyramid & Golf.

Imagine playing a game,  not in a wimpy 16 color mode or even 256 color, 
but in the 16 MILLON COLORS your computer has been waiting to show you!  
Hardwood Solitaire is one of the few games that will take advantage of 
your True Color system, which will allow you to play your game in the 
deep rich color you deserve! True Color has 65,000 times more colors than 
256 color games! WOW!
 
HWS can be played in 256 or higher video modes & even though it looks great 
in 256 colors, it�s beauty is set free in True Color.  You can play with 
portrait card faces and select card backs that are truly beautiful.

 
The graphics are incredible and we spent a lot of effort was spent to make the game fun to 
play, we figured that you've seen enough lame graphics in games, that we would treat your 
eyes to a feast for a change! Enjoy.



	
 Registered versions will:
   Have access to all three Solitaire games: Klondike, Pyramid & Golf 
 ( Klondike is available in the unregistered version)

 Registered versions will not:
   Allow you to do super human feats or Mind Meld with your dog.
 ( That can only be done with LOTS of practice & patience , belive me I know! )


 Hardware Requirements:  
			 386
			 6 megs free Hard drive space
			 6 megs ram
			 256 color display
			 Mouse

 Recommended : 		 
			 486 or Pentium
			 6 megs free Hard drive space
			 8 megs ram
			 True Color display
			 Cool looking Mouse ( Prefferably not squeeking )

 Software  Requirements : 
			 Windows 95


 Run HW_cards.exe and Hardwood solitaire will make a group in 
 the start menu automaticly.

Also try our Webpage for current Info:

    http://www.chatlink.com/~starlite/hwsol.htm

...
Vers 1.41 fixes error in new order form


vers 1.4 fixes little bugs....Stop unwanted bugs...spay or neuter your pests today! 
     And you get a new fill in order form!
     And last but not least...credit card ordering info! Yeah!



     Installation note:  Avoid long file names...HWS icon won't install appropriately...it's 
     still ok, it will just ask you were the program is and you need tell it.  So it's 
     better to avoid long file names :)
