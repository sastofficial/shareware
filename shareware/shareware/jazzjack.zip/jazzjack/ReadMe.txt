=============================================================================
                              Jazz Jackrabbit 2
                               v1.21 Shareware

                  Copyright (c) 1997-1998 Epic MegaGames, Inc.
=============================================================================
=============================================================================
                   * Instructions/Troubleshooting Info *
=============================================================================


A Note From The Developers:

            This is the Shareware version of Jazz Jackrabbit 2.

      Shareware is "Try before you buy" software that we encourage you
      to pass along to your friends, and upload to your favorite places
      on the Internet.

      This Shareware version of Jazz Jackrabbit 2 contains 3 single
      player levels, 2 multiplayer games, and a limited number of
      secrets and weapons. If you like playing this shareware version 
      of Jazz Jackrabbit 2 and you want more, please purchase the FULL 
      version to play and experience the game in its entirety.

      Select "Ordering Info" from the Main Menu of the game for 
      information on purchasing Jazz Jackrabbit 2, and to see what 
      you get when you order.

      We are happy to give you this Shareware demonstration of
      Jazz Jackrabbit 2 for your evaluation. If you enjoy the game,
      please support our continuing effort to provide you with
      quality entertainment software by purchasing the full version.

      Enjoy!

=============================================================================
                              Legal Stuff
=============================================================================

      Included with this software is the file license.doc. Please read
      and understand this document fully before accessing the game. If you
      do not agree to the terms and conditions therein, you must not access 
      the game program and completely uninstall the game from your hard 
      drive and/or any other storage media you may have stored the program.


=============================================================================
                            Getting Started
=============================================================================


Requires:

   Processor:  Intel's Pentium(R) processor, Pentium(R) processor with 
               MMX(TM) technology, Pentium(R) II processor or compatibles.
   OS:         Microsoft's Windows(R) 95.
   RAM:        16 MB.
   Hard Drive: 11 MB.
   CD ROM:     2X speed or better.
   Controller: Keyboard or Joystick (optional).


Starting Jazz Jackrabbit 2
--------------------------


Installation
------------


 To start the installation process, run the setup wizard
 by double clicking on the Jazz2sw.exe file. This setup
 wizard will ask you certain information about where and
 how you would like to install Jazz Jackrabbit 2. Follow the
 instructions given to complete the installation process.
 You can press the Cancel button at any time to stop the
 installation. You must completely finish the installation
 before you can play the game.


Direct X 
--------

Jazz Jackrabbit 2 requires DirectX 5 installed on your computer to 
run properly. If you do not have DirectX 5 installed, you can 
download it from the following sites:
                    
                    http://www.microsoft.com/DirectX
                    ftp://ftp.epicgames.com/DirectX	


NOTE: IT IS STRONGLY RECOMMENDED THAT YOU INSTALL DIRECTX 5 ON
YOUR COMPUTER TO PLAY JAZZ JACKRABBIT 2. WE CANNOT OFFER TECHNICAL
SUPPORT TO PEOPLE WHO ARE USING OLDER VERSIONS OF DIRECTX.


=============================================================================
                        Performance Issues
=============================================================================


Jazz Jackrabbit 2 was designed to utilize the latest hardware technology to 
achieve the best quality and highest possible framerate. The term framerate 
refers to how fast the screen is completely updated with new graphics. 

Jazz 2 is capable of framerates over 70 frames per second (fps), although 
human eyes can barely distinguish framerates above 30 fps. This means Jazz 
Jackrabbit 2 can produce ultra-smooth animation and gameplay under certain 
hardware conditions.

Jazz 2 has different quality settings you can adjust to get the best 
performance from your computer. These options can be changed from the
Options Menu from within the game. Your computer's processor, video card 
and sound card all affect your framerate. We suggest starting out at the 
highest quality settings, then lowering them as needed until you achieve 
the best mix of quality and speed for your computer. 

Here are some tips:

� Make sure you have the latest drivers for your graphics card and sound 
  card. Contact the manufacturers on the World Wide Web or call them to 
  make sure you have the latest drivers.

� Play in Full-screen mode. In windowed mode, it takes more processor 
  power to draw all the graphics in the game as well as the graphics on 
  your Windows desktop.

� Try changing the Resolution to an 8-bit video mode. This will lower 
  the number of colors used in the game, but will definitely help 
  increase performance.

� If your graphics card has good 2D acceleration built in, try turning 
  Hardware Mode on. Note: You will lose realtime lighting and transparency 
  effects in the game, but, unless you have a fast system, Ambient Lighting 
  can lower your framerate dramatically.

� As a last resort, turn off Textured 3D Background. Unless you have a very 
  slow computer, you shouldn't have to turn this option off because the 
  performance gain is fairly small.


=============================================================================
                     Party Mode - Multiplayer Notes
=============================================================================

Talking to Other Players
------------------------

During an Internet game, you can 'talk' to all the players in the game, or 
'talk' to your team mates privately.

To start talking to all the players, press the "T" key on your keyboard.
Then, type in what you would like to say. Finish by pressing the ENTER
key. When you press ENTER, your text will be sent to all the other players
in the game. If you press "T" and decide you would rather not say anything,
press the ESC key to go back to the game.

In Capture The Flag, if you would like to talk in private with your team 
mates, press SHIFT+T. This way, you can talk about strategies with your 
team without your opponent listening. If you or one of your team mates types 
private text, their name will be displayed between the "[" and "]" brackets.
 

=============================================================================
                    Known Problems and Solutions
=============================================================================

- Jazz Jackrabbit 2 may have problems if a joystick or gamepad is removed 
  during gameplay. If this happens, you should exit Jazz Jackrabbit 2, plug 
  the joystick or gamepad back in, and restart the game before attempting 
  to continue.

- In some multiplayer modes, it may be possible for the players characters 
  to get "stuck" if more than one character tries to access a spring at the
  same time. If this happens, you will have to start a new game to continue.

- In battle mode, it may be possible for the players' characters to
  get stuck if more than one character tries to access a pole at the
  same time. If this happens, you should still be able to shoot. The game
  will continue when one of the stuck players gets killed.



=============================================================================
                   Visit the Jazz Jackrabbit Home Page!
=============================================================================

For information about updates, add-ons, competitions, and new products, 
visit the Jazz Jackrabbit Web site on the World Wide Web! Just point 
your browser to:  

                      http://www.jazzjackrabbit.com


For information about current and upcoming games from Epic MegaGames, late 
breaking news, and cool links, visit:

                         http://www.epicgames.com


=============================================================================
                               Credits
=============================================================================


                    Arjan Brussee   Lead Programmer
                 Michiel Ouwehand   Programmer
                     Nick Stadler   Art, Animation, Design
                 Cliff Bleszinski   Level Design, Co-producer
                Alexander Brandon   Music
                     Dean Dodrill   Cinematic Animation
                       Nando Eweg   Sound Effects
                    Jon MacLellan   Additional Level Design

                  Robert A. Allen   Producer
                 
                  Carlo Vogelsang   Sound Engine Programming 
   
                  Robert A. Allen   Additional Music
                       Sean Hiler   Additional Music


                            Support Group

                 Cultural Fluency   Translations
                   Craig Lafferty   Public Relations Manager
                    Jon MacLellan   Webmaster
                    Chris Hargett   Server Meister
                       Mike Forge   Manual
                        Mark Rein   Marketing
                       Jay Wilbur   Imperial Advisor
                       Nigel Kent   Administration

                             Project Two

                    Martin Jansen   Product Manager/Webmaster
                  Hester Leeflang   Marketing Manager
                  Martin de Ronde   PR Manager
                   Marieke Jansen   Sales Manager
                    John Williams   International Sales Director

 
                            Special Thanks

         Tom Pearson, Paul Chandler, Aaron Levinson, Shelly Fuko,
                  Diana Gowen, Scotty Cone, Will Sweat,  
                     The Epic MegaGames Beta Testers


=============================================================================
                          Epic MegaGames, Inc
                   3204 Tower Oaks Blvd., Suite 410
                            Rockville, MD
                                20852
=============================================================================
=============================================================================
       Copyright (c) 1997-1998 Epic MegaGames, Inc. All rights reserved.
         Pentium is a registered trademark of Intel Corporation.
         Windows is a registered trademark of Microsoft Corporation.
