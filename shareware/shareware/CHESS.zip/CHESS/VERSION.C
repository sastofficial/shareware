char Version[]="Sun Jun 16 19:41:00 1991";
