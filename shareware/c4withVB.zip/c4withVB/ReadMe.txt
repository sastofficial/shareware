
	 	      Connect 4 Game for Windows 95
			   by Michael Barrett
		     -------------------------------

-How to run

Just double-click on Connect4.exe! If you already have 'vb40032.dll' 
(probably in your Windows\System folder), you can delete this one.  Otherwise
put this one in the Windows\System folder.

-How to play

The object of the game is to get four counters in a row, vertically, 
horizontally or diagonally.  The counters in each column have to start from 
the bottom and pile upwards.  Just click on anywhere in a column to move in 
that column. You can also press the keys '1' (the far left column) to '7'(far
right) to move in a column.  In one player, the user is yellow and the 
computer is red. Yellow always moves first, in both one and two player modes. 

-How to pay, if you like the game

It's SIMPLE AND CHEAP! Just send $2.00 (just two!) or the rough equivalent in
any other currency (ANY other) to:

Michael Barrett
29 Saval Park Gardens
Dalkey
Co. Dublin
Ireland

If you like the game, PLEASE send the money. Your payment will make a 
difference! Thank you.

If you have any suggestions/comments/queries/bugs or anything else you can 
e-mail me at:
barrett@indigo.ie

Connect 4 was written in Visual Basic 4.0
If you want the source code you can e-mail me at the address above.
Thanks for reading this far!   :)